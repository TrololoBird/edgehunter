# MASTER FINDINGS REGISTER

Накопительный реестр EdgeHunter. Источники до Sprint 1 импортированы без удаления исходных ID: `EDGEHUNTER_DEFECT_REGISTRY.md` и `V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md`. Полные исходные evidence, статусы и обязательства сохранены в `MASTER_FINDINGS.json`; исходные реестры не изменены.

Записей: 57 (D-series: 16; DEF-series: 34; Sprint 1: 7).

## Sprint 1

| ID | Status | Finding / root cause | Fix | Verification |
|---|---|---|---|---|
| SPR1-DATA-001 | RESOLVED | Binance REST OI updated freshness before validating the response and sampled at local receive time; invalid OI could be treated as fresh. | Validate positive finite OI and exchange timestamp first; return (OI, exchange_ms), persist receive time separately, use exchange time for OI samples and freshness; validate seed history. | tests/test_regressions.py::test_open_interest_uses_exchange_timestamp_and_rejects_invalid_values |
| SPR1-DATA-002 | RESOLVED | HTTP 200 or parsed JSON was treated as a valid book and quality was refreshed without business-code or market-data checks. | Require HTTP success, OKX code 0 / Bybit retCode 0, bids and asks, finite positive levels, valid sorted non-crossed snapshot; expose transport/API/content/freshness stages and preserve prior fetched_at on invalid data. | tests/test_regressions.py::test_rest_book_validation_rejects_bad_structure_values_and_crossed_book; tests/test_regressions.py::test_rest_book_status_separates_stages_and_expires_freshness |
| SPR1-HEALTH-001 | RESOLVED | UI rendered any venue without connected=0/false as healthy; missing connection data became an implicit positive. | Add explicit CONNECTED, DISCONNECTED, NOT_CONFIGURED, STALE, UNKNOWN states; aggregation and UI treat absent data as UNKNOWN and unknown/stale/down as unhealthy. | tests/test_regressions.py::test_missing_websocket_connection_information_is_unknown; node --check web/app.js |
| SPR1-HEALTH-002 | RESOLVED | A configured stream with a known zero connection count and no prior messages remained UNKNOWN, conflating disconnection with missing information. | Known zero becomes DISCONNECTED; absent/invalid connection data remains UNKNOWN; grouped Binance streams use the same rules. | tests/test_regressions.py::test_configured_websocket_with_zero_connections_is_disconnected; tests/test_regressions.py::test_missing_websocket_connection_information_is_unknown; node --check web/app.js |
| SPR1-FLOW-001 | RESOLVED | REST 1m/5m taker aggregates were inserted into the per-second event-flow ring and represented as trade flow; spot delta combined candle aggregates and live prints without provenance. | Keep OHLCV history for warm-up; store legacy REST seed calls in a separately tagged observation buffer, exclude them from event-flow/CVD and whale inputs; expose separate spot candle delta, event-flow CVD and source label while retaining the legacy combined field. Candle divergence is documented as OHLCV-derived. | tests/test_regressions.py::test_rest_minute_seed_stays_out_of_event_flow_ring; targeted suite passed. |
| SPR1-FLOW-002 | RESOLVED | Activity was counted by non-zero venue net only; balanced buy/sell flow was inactive and top venue share was derived from absolute net, conflating participation and concentration. | Keep old fields and semantics; add gross_flow_5m, net_flow_5m, venues_flow_active, net_venues_active, top_gross_venue/share and net_top_venue_share; UI uses explicit gross concentration. | tests/test_regressions.py::test_cross_venue_gross_activity_survives_zero_net_flow |
| SPR1-MKT-001 | RESOLVED | Binance force orders could use original q when executed z was absent/zero, did not require FILLED, and cross-venue aggregate liquidations could suppress unrelated sweeps. Public feeds were described as complete. | Require FILLED, positive finite executed quantity z, positive average execution price ap and valid side/time; compute notional from z; correlate only same venue in the existing short interval; describe all public streams as partial observations. | tests/test_regressions.py::test_binance_liquidation_uses_filled_executed_quantity; tests/test_regressions.py::test_liquidation_attribution_can_be_limited_to_matching_venue; tests/test_regressions.py::test_other_venue_liquidations_do_not_suppress_sweep |

## Imported findings

| ID | Current status | Original evidence / action | Source |
|---|---|---|---|
| D-001 | VERIFIED | Historical records contain both string and boolean representations; classifier uses identity check | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-002 | VERIFIED | Archive contains b169a, b168y and missing rules_v; current code uses a newer rules version | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-003 | VERIFIED/PARTIAL | Scenario, order intent and fill are historically coupled; new limit-on-retest needs replay evidence | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-004 | VERIFIED/PARTIAL | plan and display historically used different bases/cost semantics | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-005 | VERIFIED/PARTIAL | zone construction requires explicit closed-bar input; all downstream consumers are not yet proven | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-006 | VERIFIED | OUTCOME_HOURS and UI wording historically diverged | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-007 | OPEN | label and structural tfs must be traced through RawLevel, cluster and merge | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-008 | OPEN | p50/p80 source window and calibration timestamp not yet proven for every record | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-009 | VERIFIED/PARTIAL | WebSocket live state and cached REST analysis have different freshness semantics | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-010 | VERIFIED | no universal publication → scenario → evidence → snapshot contract | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-011 | VERIFIED | no universal versioned correction model for source events and derived evidence | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-012 | VERIFIED/PARTIAL | component quality states exist but no global publication gate is proven | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-013 | VERIFIED | system pytest fails imports; project venv + PYTHONPATH passes | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-014 | VERIFIED | process started before current working-tree changes; disk and memory can diverge | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-015 | OPEN | overlapping scenario windows require episode/block inference; no universal contract yet | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| D-016 | OPEN | interpolated values are rendered through HTML templates; full taint review pending | docs/EDGEHUNTER_DEFECT_REGISTRY.md |
| DEF-SEC-001 | FIXED / REMAINING | Checkout credentials were removed from the local override and the executor reads environment variables only. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-SEC-002 | FIXED | Config-file fallback is not used; missing environment credentials disable execution. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ML-001 | QUARANTINED | Live anomaly/regime/success/trade ML flags are disabled; old model hooks cannot make a v2 decision. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ML-002 | QUARANTINED | Legacy warm-start paths are outside the v2 journal/model paths. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-FLOW-001 | FIXED | Lead-flow correlation uses minute `k` as predictor and the next complete return as target. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-MKT-001 | QUARANTINED | Price/OI labels now describe expansion/contraction and do not assert new longs, new shorts, covering or liquidation; phase scoring is disabled. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-MKT-002 | QUARANTINED | CVD/delta outputs are observation fields; accumulation/distribution phase scoring cannot run. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-MKT-003 | PARTIAL | Iceberg wording is reduced to aggregate replenishment-like L2 behavior without order identity; old detector is not source-gated into v2. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-MKT-004 | PARTIAL | Force-order records are labelled partial public observations and no longer mean total market liquidation volume. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-DATA-001 | PARTIAL | Settled funding and next-estimate funding are stored separately; replay no longer charges an unobserved future settlement. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-POS-001 | FIXED | Hyperliquid fields and liquidation levels are explicitly restricted to selected tracked accounts and platform estimates. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ZONE-001 | PARTIAL | Volume Profile documentation now states that candle-volume spreading is an OHLC approximation, not time-at-price or Dalton Market Profile. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ZONE-002 | FIXED | Estimated liquidation clusters are marked as model outputs and cannot be treated as observed liquidation levels or directional evidence. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-MACRO-001 | PARTIAL | Strict mode refuses current revised FRED rows without release/vintage timestamps. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-PRE-001 | QUARANTINED | `pretrain.py` and `replay.py` refuse to run with the empty v2 registry; old outputs are archive-only. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-EXEC-001 | PARTIAL | Reference price, estimated replay fill and actual exchange fill have separate fields; no source-gated strategy can reach execution. `core/execution_reconciler.py` now rejects fill states without exchange evidence and deduplicates user-data events. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-EXEC-002 | FIXED | OHLC/limit touch returns `UNSUPPORTED_LIMIT_MODEL`; it is not recorded as a full fill. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-EXEC-003 | PARTIAL | v2 rows mark reference-only outcomes and do not populate actual exchange fills from replay; `record_entry` rejects an unregistered strategy. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-EXEC-004 | PARTIAL | Unobserved future funding is removed from replay; model slippage remains clearly estimated. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-STAT-001 | QUARANTINED | Adaptive hit-rate gates and legacy geometry promotions cannot run with the empty registry. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-STAT-002 | QUARANTINED | Confirmation promotion is disabled and requires a source-gated strategy. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-STAT-003 | FIXED | Anomaly effect denominator uses the documented median rather than a mean. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-STAT-004 | FIXED | Universe baselines select only snapshots at or before the target timestamp. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-STAT-005 | QUARANTINED | Legacy DSR/PBO/threshold-selection reports are not used by v2 and ML is disabled. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-ORB-001 | REMOVE | Legacy ORB classes are not registered; the source manifest marks them `REMOVE`. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-DALTON-001 | REMOVE | Value-area/auction classes and Dalton labels are quarantined; no exact primary rule was established for the old implementation. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-CONNORS-001 | REMOVE | RSI(2) legacy class is not registered because its variants/exits exceed the checked published rule. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-TURTLE-001 | REMOVE | Legacy breakout class is not a complete Turtle implementation and is not registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-WYCKOFF-001 | REMOVE | The invented A–F phase taxonomy is not admitted and phase scoring is disabled. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-WYCKOFF-002 | REMOVE | Numeric spring constraints are not attributed to Wyckoff and the old strategy is not registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-SEIDEN-001 | REMOVE | Supply/demand score, 3:1 and touch-fill rules have no verified primary source and are not registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-BOLL-001 | REMOVE | The old Method I/III classes mixed Bollinger terminology with unsourced OI/delta/funding conditions and are not registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ATTR-CUP-001 | REMOVE | Cup/handle numeric algorithm is not source-verified and is not registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |
| DEF-ICT-001 | REMOVE | ICT/OTE/Silver Bullet classes mix terms with unverified conditions and execution assumptions; none is registered. | docs/V2_DEFECT_REMEDIATION_REGISTER_2026-11-17.md |

## Status history and interpretation

Все исходные ID и исходные формулировки сохранены. История импорта указана в JSON `status_history`; для Sprint 1 статус RESOLVED проставлен после целевых проверок. `DEF-MKT-004` оставлен PARTIAL: исправлены утверждения о полноте и source attribution, но отдельная количественная coverage/freshness модель для каждого liquidation stream остаётся открытой.

История исходного health finding сохранена; отдельный обратный дефект зарегистрирован как `SPR1-HEALTH-002`. Подробные функции, исправления, изменённые файлы и команды проверки находятся в `docs/SPRINT1_REPORT.md`.
