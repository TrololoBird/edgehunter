"""Optional external observations for the dashboard and journal.

These adapters query separate venues and providers. Each returned value must
retain its source, timestamp, units and freshness; a value from one venue is
not a market-wide measure and is not interchangeable with another venue's
field. The v2 decision path does not infer intent, causality, complete market
liquidations or a trading edge from these observations.
"""
import asyncio
import time
import csv
import io
import json
import logging
import errors
import os
from datetime import datetime, timezone
from typing import Dict, Optional
from zoneinfo import ZoneInfo

import aiohttp
from config import CONFIG
from data_quality import quality

logger = logging.getLogger(__name__)

DERIBIT = 'https://www.deribit.com/api/v2/public'
HL = 'https://api.hyperliquid.xyz/info'
OKX = 'https://www.okx.com/api/v5'
BYBIT = 'https://api.bybit.com/v5'
VIX_CSV = 'https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv'
FNG = 'https://api.alternative.me/fng/?limit=1'
TRADFI = {'xau': 'XAUUSDT', 'oil': 'CLUSDT', 'spy': 'SPYUSDT', 'qqq': 'QQQUSDT'}
ETF_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'etf_flows.json')
CAL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'us_calendar.json')
NY = ZoneInfo('America/New_York')
_CAL = (None, set(), set())
UPBIT = 'https://api.upbit.com/v1'
UPBIT_MAX_AGE_S = 180
UPBIT_TICKER_BATCH = 80        # Upbit documents a maximum of 100 market codes per ticker request.
_CAL_CHECKED = 0.0
ETF_LAG_H = 32
ETF_MAX_AGE_D = 6        # a last visible day older than this (Farside timer dead) is NULL, not a stale value
SLOW_MAX_AGE_S = 2 * 86400   # VIX / Fear & Greed not refreshed for this long: NULL, never an old value


def okx_taker_rows(payload) -> list[tuple[int, float, float]]:
    """Normalize OKX Rubik taker-volume rows to (timestamp_ms, sell, buy).

    The endpoint returns strings and has historically returned both millisecond
    and second timestamps in fixtures. Invalid rows are discarded by the
    caller's counter instead of being interpreted as zero flow.
    """
    if not isinstance(payload, dict) or payload.get('code') not in (None, '0', 0):
        return []
    data = payload.get('data')
    if not isinstance(data, list):
        return []
    out = []
    for row in data:
        if not isinstance(row, (list, tuple)) or len(row) < 3:
            continue
        try:
            ts = int(float(row[0]))
            if ts < 10_000_000_000:  # OKX fixtures/API variants may use epoch seconds
                ts *= 1000
            sell, buy = float(row[1]), float(row[2])
            if ts <= 0 or sell < 0 or buy < 0:
                continue
        except (TypeError, ValueError, OverflowError):
            continue
        out.append((ts, sell, buy))
    return out


def okx_completed_bucket(ts_ms: int, started_ms: int) -> Optional[int]:
    """Return a 5m bucket start for either OKX timestamp convention."""
    if ts_ms + 300_000 <= started_ms:
        return ts_ms
    if ts_ms <= started_ms:
        return ts_ms - 300_000
    return None


def us_session(now_s: float) -> Optional[int]:
    """1 = the NYSE regular session (09:30-16:00 New York, 13:00 on early closes) is open, 0 = closed. The holidays and
    early closes come from us_calendar.json (tools/farside_flows.py writes it from exchange_calendars: pandas stays out
    of the bot); without the file the weekday and the hours alone decide."""
    global _CAL, _CAL_CHECKED
    if time.time() - _CAL_CHECKED >= 60:      # eng-134: a stat per card stalled the loop (watchdog: getmtime)
        _CAL_CHECKED = time.time()
        try:
            mt = os.path.getmtime(CAL_FILE)
            if _CAL[0] != mt:
                with open(CAL_FILE, encoding='utf-8') as f:
                    c = json.load(f)
                _CAL = (mt, set(c.get('closed', ())), set(c.get('early', ())))
        except Exception as e:               # a missing / broken / wrong-typed file: weekday and hours decide
            errors.report('extdata.nyse_calendar', e, f"{CAL_FILE}: weekday and hours decide")
    t = datetime.fromtimestamp(now_s, timezone.utc).astimezone(NY)
    if t.weekday() >= 5 or t.strftime('%Y-%m-%d') in _CAL[1]:
        return 0
    close = 13 * 60 if t.strftime('%Y-%m-%d') in _CAL[2] else 16 * 60
    return int(9 * 60 + 30 <= t.hour * 60 + t.minute < close)


def etf_flows_visible(flows: Dict[str, float], now_s: float):
    """(last visible day's net flow, sum of the last 3 visible days) in USD m; a day D counts from D+1 08:00 UTC."""
    vis, last_t = [], 0.0
    for d, v in sorted(flows.items()):
        try:
            t = datetime.strptime(d, '%Y-%m-%d').replace(tzinfo=timezone.utc).timestamp()
        except ValueError as e:
            errors.report('extdata.etf_flows', e, f"flow date {d!r} skipped")
            continue
        if t + ETF_LAG_H * 3600 <= now_s and v is not None:
            vis.append(float(v))
            last_t = t
    return (vis[-1], sum(vis[-3:])) if vis and now_s - last_t < ETF_MAX_AGE_D * 86400 else (None, None)


class ExternalData:
    def __init__(self, fetcher):
        self.fetcher = fetcher
        self.market: Dict[str, Optional[float]] = {'dvol_btc': None, 'dvol_chg_1h': None, 'pc_oi_btc': None}
        for k in TRADFI:
            self.market[f'{k}_chg_1h'] = self.market[f'{k}_chg_24h'] = None
        self.market.update({'us_session': None, 'vix_prev': None, 'fng': None, 'etf_flow_1d': None, 'etf_flow_3d': None})
        self.coin: Dict[str, Dict[str, float]] = {}
        self._session: Optional[aiohttp.ClientSession] = None
        self._tradfi_ok: Dict[str, float] = {}
        self._slow_ok: Dict[str, float] = {}
        self._slow_stale: set = set()
        self._upbit: Dict[str, tuple] = {}       # coin -> (KRW price, its last trade time s)
        self._upbit_t = 0.0
        self.okx_seed_stats = {
            'coins': 0, 'requests': 0, 'responses': 0, 'rows': 0,
            'buckets_written': 0, 'window_misses': 0, 'empty': 0, 'malformed': 0, 'errors': 0,
        }

    async def _json(self, url: str, payload=None):
        if self._session is None:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(
                total=CONFIG.rest.total_timeout_sec, connect=CONFIG.rest.connect_timeout_sec,
                sock_read=CONFIG.rest.read_timeout_sec))
        import asyncio
        for attempt in range(3):
            try:
                if payload is None:
                    async with self._session.get(url) as r:
                        return await r.json(content_type=None)
                async with self._session.post(url, data=json.dumps(payload), headers={'Content-Type': 'application/json'}) as r:
                    return await r.json(content_type=None)
            except (aiohttp.ClientError, asyncio.TimeoutError, ConnectionResetError):
                if attempt == 2:
                    raise
                await asyncio.sleep(0.25 * (2 ** attempt))

    async def close(self):
        if self._session is not None:
            await self._session.close()

    # ------------------------------------------------------------------ eng-133: macro shadow features
    async def macro_loop(self, running):
        """TradFi perpetuals every 5 min; VIX / Fear & Greed / ETF file every 30 min. Journal context only."""
        last_slow = 0.0
        while running():
            for k, sym in TRADFI.items():
                try:
                    rows = await self.fetcher._rest_call(self.fetcher.futures_exchange, 'fapiPublicGetKlines',
                                                         {'symbol': sym, 'interval': '1h', 'limit': 27}, priority=1)
                    c = [float(r[4]) for r in rows]          # CLOSED candles only: c[-1] is the live one
                    if len(c) < 27:
                        raise ValueError('short klines')
                    self.market[f'{k}_chg_1h'] = (c[-2] / c[-3] - 1) * 100
                    self.market[f'{k}_chg_24h'] = (c[-2] / c[-26] - 1) * 100
                    self._tradfi_ok[k] = time.time()
                except Exception as e:
                    logger.debug(f"TradFi shadow feature {k}: {e!r}")
                    if time.time() - self._tradfi_ok.get(k, 0) > 3 * 3600:        # stale: NULL, never an old value
                        self.market[f'{k}_chg_1h'] = self.market[f'{k}_chg_24h'] = None
            if time.time() - last_slow > 1800:
                last_slow = time.time()
                await self._slow_macro()
            await asyncio.sleep(300)

    async def _slow_macro(self):
        try:
            if self._session is None:
                self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(
                    total=CONFIG.rest.total_timeout_sec, connect=CONFIG.rest.connect_timeout_sec,
                    sock_read=CONFIG.rest.read_timeout_sec))
            async with self._session.get(VIX_CSV) as r:
                text = await r.text()
            today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
            prev = None
            lines = text.splitlines()
            for row in csv.DictReader(io.StringIO('\n'.join(lines[:1] + lines[-12:]))):
                d = datetime.strptime(row['DATE'], '%m/%d/%Y').strftime('%Y-%m-%d')
                if d < today:                      # the previous session's close only: today's bar is not final
                    prev = float(row['CLOSE'])
            if prev is None:
                raise ValueError('no VIX row before today')
            self.market['vix_prev'] = prev
            self._slow_fresh('vix_prev')
        except Exception as e:
            self._slow_failed('vix_prev', e)
        try:
            d = await self._json(FNG)
            self.market['fng'] = float(d['data'][0]['value'])
            self._slow_fresh('fng')
        except Exception as e:
            self._slow_failed('fng', e)
        try:
            with open(ETF_FILE, encoding='utf-8') as f:
                self.market['etf_flow_1d'], self.market['etf_flow_3d'] = etf_flows_visible(json.load(f), time.time())
        except OSError:
            pass                                   # no file yet (the Farside timer is not installed): NULL
        except Exception as e:
            self.market['etf_flow_1d'] = self.market['etf_flow_3d'] = None
            errors.report('extdata.etf_file', e, "etf_flows.json")

    def _slow_fresh(self, key: str):
        self._slow_ok[key] = time.time()
        self._slow_stale.discard(key)

    def _slow_failed(self, key: str, e: Exception):
        logger.debug(f"{key} shadow feature: {e!r}")
        if time.time() - self._slow_ok.get(key, 0) > SLOW_MAX_AGE_S:          # stale: NULL, one WARNING
            self.market[key] = None
            if key not in self._slow_stale:
                self._slow_stale.add(key)
                errors.report('extdata.slow_macro', e, f"{key} not refreshed for 2 days")

    def of(self, symbol: str) -> Dict[str, float]:
        return self.coin.get(symbol, {})

    # ------------------------------------------------------------------ eng-134: Upbit (kimchi premium)
    async def _upbit_ticker_chunk(self, markets: list[str], invalid: list[str]) -> list:
        """Fetch one ticker batch, isolating a stale/delisted code without dropping all KRW prices."""
        payload = await self._json(f"{UPBIT}/ticker?markets={','.join(markets)}")
        if isinstance(payload, list):
            return payload
        error = payload.get('error') if isinstance(payload, dict) else None
        name = str(error.get('name', '') if isinstance(error, dict) else '').lower()
        message = str(error.get('message', '') if isinstance(error, dict) else '').lower()
        unknown_market = name in {'404', 'not found'} or 'code not found' in message
        if unknown_market and len(markets) > 1:
            middle = len(markets) // 2
            return (await self._upbit_ticker_chunk(markets[:middle], invalid)
                    + await self._upbit_ticker_chunk(markets[middle:], invalid))
        if unknown_market and len(markets) == 1:
            invalid.append(markets[0])
            return []
        raise ValueError(f"Upbit ticker answered {str(payload)[:150]}")

    async def _upbit_tickers(self, markets: list[str]) -> tuple[list, list[str]]:
        rows, invalid = [], []
        for start in range(0, len(markets), UPBIT_TICKER_BATCH):
            rows.extend(await self._upbit_ticker_chunk(markets[start:start + UPBIT_TICKER_BATCH], invalid))
        return rows, invalid

    async def upbit_loop(self, running):
        markets, listed_at = [], 0.0
        retry_delay = 60
        while running():
            try:
                if not markets or time.time() - listed_at > 3600:
                    rows = await self._json(f"{UPBIT}/market/all")
                    if not isinstance(rows, list):
                        raise ValueError(f"Upbit market/all answered {str(rows)[:150]}")
                    markets = [x['market'] for x in rows if isinstance(x, dict)
                               and str(x.get('market', '')).startswith('KRW-')]
                    if not markets:
                        raise ValueError('Upbit market/all returned no KRW markets')
                    listed_at = time.time()
                rows, invalid = await self._upbit_tickers(markets)
                markets = [market for market in markets if market not in set(invalid)]
                parsed = {}
                for row in rows:
                    try:
                        market = str(row.get('market', ''))
                        price = float(row.get('trade_price'))
                        traded = float(row.get('trade_timestamp') or 0) / 1000
                    except (AttributeError, TypeError, ValueError):
                        continue
                    if market.startswith('KRW-') and price > 0:
                        parsed[market[4:]] = (price, traded)
                if not parsed:
                    raise ValueError(f"Upbit ticker returned no usable rows ({len(rows)} received)")
                self._upbit = parsed
                self._upbit_t = time.time()
                retry_delay = 60
            except Exception as e:
                errors.report('extdata.upbit_loop', e, "Upbit KRW tickers")
                retry_delay = min(600, max(120, retry_delay * 2))
            await asyncio.sleep(retry_delay)

    def kimchi(self, symbol: str, price: Optional[float]) -> Optional[float]:
        """Upbit premium % of a coin over its Binance futures price; None when stale / not listed."""
        usdt = self._upbit.get('USDT', (None,))[0]
        if not price or not usdt or time.time() - self._upbit_t > UPBIT_MAX_AGE_S:
            return None
        base = symbol.split('/')[0]
        mult = 1.0
        from symbols import split_base
        coin, k = split_base(base)
        if k != 1.0 and coin in self._upbit:                     # 1000PEPE is quoted per 1000 coins (10000WEN per 1e4)
            base, mult = coin, k
        krw, traded = self._upbit.get(base, (None, 0))
        if not krw or time.time() - traded > UPBIT_MAX_AGE_S:     # an illiquid pair's last trade is an old price
            return None
        prem = (krw * mult / usdt / price - 1) * 100
        # same ticker, another coin (KRW-EDGE is Definitive, EDGEUSDT is not: -67%); real premiums stay well inside
        return prem if abs(prem) <= 30 else None

    # ------------------------------------------------------------------ Deribit
    async def deribit_loop(self, running):
        while running():
            try:
                now = int(time.time() * 1000)
                d = await self._json(f"{DERIBIT}/get_volatility_index_data?currency=BTC&start_timestamp="
                                     f"{now - 4 * 3_600_000}&end_timestamp={now}&resolution=3600")
                rows = (d.get('result') or {}).get('data') or []
                if len(rows) >= 2:
                    last, prev = rows[-1][4], rows[-2][4]
                    self.market['dvol_btc'] = float(last)
                    self.market['dvol_chg_1h'] = float(last) - float(prev)
                    if abs(last - prev) >= 3:
                        logger.warning(f"Market anomaly: BTC DVOL {prev:.1f} -> {last:.1f} in 1h")
                b = await self._json(f"{DERIBIT}/get_book_summary_by_currency?currency=BTC&kind=option")
                puts = calls = 0.0
                for o in b.get('result') or []:
                    name, oi = o.get('instrument_name', ''), float(o.get('open_interest') or 0)
                    if name.endswith('-P'):
                        puts += oi
                    elif name.endswith('-C'):
                        calls += oi
                self.market['pc_oi_btc'] = puts / calls if calls else None
            except Exception as e:
                errors.report('extdata.deribit_loop', e, "Deribit")
            await asyncio.sleep(300)

    # ------------------------------------------------------------------ Hyperliquid predicted fundings
    def _key_of_coin(self, coin: str) -> Optional[str]:
        sm = self.fetcher.symbol_map
        m = sm.lookup('hyperliquid', coin)
        if m is not None:
            return m.key
        for key in [f"{coin}/USDT:USDT"] + [f"{p}{coin}/USDT:USDT" for p in ('1000', '10000', '100000', '1000000', '1M')]:
            if key in self.fetcher.markets:
                return key
        return None

    async def funding_loop(self, running):
        while running():
            try:
                rows = await self._json(HL, {'type': 'predictedFundings'})
                for coin, venues in rows or []:
                    key = self._key_of_coin(coin)
                    if key is None:
                        continue
                    rates = []
                    for _, v in venues:
                        if not v:
                            continue
                        hours = float(v.get('fundingIntervalHours') or 8) or 8
                        rates.append(float(v['fundingRate']) * 8 / hours)
                    if len(rates) >= 2:
                        self.coin.setdefault(key, {})['funding_spread'] = max(rates) - min(rates)
            except Exception as e:
                errors.report('extdata.funding_loop', e, "predictedFundings")
            await asyncio.sleep(300)

    # ------------------------------------------------------------------ OKX flow seed
    async def seed_okx_flow(self):
        """Once, after the streams started: 5m OKX taker volume of the 15 minutes before them into the flow windows."""
        started = self.fetcher.streams_started_ms
        if not started:
            return
        coins = {}
        for key in list(self.fetcher.markets):
            for m in self.fetcher.symbol_map.by_key.get(key, {}).values():
                if m.venue == 'okx':
                    coins[m.coin] = key
        self.okx_seed_stats['coins'] = len(coins)
        seeded = 0
        for coin, key in coins.items():
            try:
                self.okx_seed_stats['requests'] += 1
                d = await self._json(f"{OKX}/rubik/stat/taker-volume?ccy={coin}&instType=CONTRACTS&period=5m")
                self.okx_seed_stats['responses'] += 1
                raw = d.get('data') if isinstance(d, dict) else None
                if not raw:
                    self.okx_seed_stats['empty'] += 1
                rows = okx_taker_rows(d)
                self.okx_seed_stats['rows'] += len(rows)
                if raw and not rows:
                    self.okx_seed_stats['malformed'] += 1
                for t, sell, buy in rows[:4]:
                    # Rubik versions have used both bucket-open and bucket-close
                    # timestamps. Convert either form to the start of the last
                    # completed bucket before the stream start.
                    bucket = okx_completed_bucket(t, started)
                    if bucket is not None and started - 15 * 60_000 <= bucket and bucket + 300_000 <= started:
                        for k in range(5):      # the 5m bucket spread over its minutes
                            self.fetcher.flow.seed_minute('okx', key, bucket + k * 60_000,
                                                          float(buy) / 5, float(sell) / 5, 0)
                        seeded += 1
                        self.okx_seed_stats['buckets_written'] += 1
                    else:
                        self.okx_seed_stats['window_misses'] += 1
            except Exception as e:
                self.okx_seed_stats['errors'] += 1
                errors.report('extdata.seed_okx_flow', e, f"OKX taker volume {coin}")
            await asyncio.sleep(0.45)           # rubik: 5 requests / 2s
        logger.info(f"OKX flow seeded: {seeded} 5m buckets for {len(coins)} coins; "
                    f"requests={self.okx_seed_stats['requests']} rows={self.okx_seed_stats['rows']} "
                    f"buckets={self.okx_seed_stats['buckets_written']} misses={self.okx_seed_stats['window_misses']} "
                    f"empty={self.okx_seed_stats['empty']} malformed={self.okx_seed_stats['malformed']} "
                    f"errors={self.okx_seed_stats['errors']}")

    # ------------------------------------------------------------------ cross-venue books
    @staticmethod
    def _imbalance(bids, asks) -> Optional[float]:
        if not bids or not asks:
            return None
        mid = (float(bids[0][0]) + float(asks[0][0])) / 2
        bid = sum(float(p) * float(q) for p, q, *_ in bids if float(p) >= mid * 0.995)
        ask = sum(float(p) * float(q) for p, q, *_ in asks if float(p) <= mid * 1.005)
        return (bid - ask) / (bid + ask) if bid + ask else None

    async def books_loop(self, running):
        while running():
            started = time.time()
            for key in self.fetcher.depth.active():
                venues = self.fetcher.symbol_map.by_key.get(key, {})
                try:
                    okx = next((m for m in venues.values() if m.venue == 'okx'), None)
                    if okx is not None:
                        d = await self._json(f"{OKX}/market/books?instId={okx.native}&sz=50")
                        book = (d.get('data') or [{}])[0]
                        self.coin.setdefault(key, {})['okx_book_imb'] = self._imbalance(book.get('bids'), book.get('asks'))
                    byb = next((m for m in venues.values() if m.venue == 'bybit'), None)
                    if byb is not None:
                        d = await self._json(f"{BYBIT}/market/orderbook?category=linear&symbol={byb.native}&limit=50")
                        r = d.get('result') or {}
                        self.coin.setdefault(key, {})['bybit_book_imb'] = self._imbalance(r.get('b'), r.get('a'))
                except Exception as e:
                    errors.report('extdata.books_loop', e, f"books {key}")
                    self.quality_state = getattr(self, 'quality_state', {})
                    previous = self.quality_state.get(('book', key))
                    self.quality_state[('book', key)] = quality(time.time(), previous.fetched_at if previous else None,
                                                               30, 120, 'cross_venue_books', type(e).__name__)
                else:
                    self.quality_state = getattr(self, 'quality_state', {})
                    now = time.time()
                    self.quality_state[('book', key)] = quality(now, now, 30, 120, 'cross_venue_books')
                await asyncio.sleep(0.3)
            await asyncio.sleep(max(5.0, 60 - (time.time() - started)))
